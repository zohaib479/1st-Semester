#include<stdio.h>
#include<string.h>
typedef struct worker{
	int worker_id;
	char f_name[50];
	char l_name[50];
	int salary;
	char date[50];
	char dep[10];
}worker;
typedef struct bonus{
	int worker_ref_id;
	char b_date[50];
	int b_amount;
}bonus;
typedef struct title{
	int worker_id_ref;
	char worker_title[20];
	char Affect_from[50];
}title;
 
 
 worker wor_arr[8]={
{1,"Monica","Arora",100000,"2014-02-20 09:00:00","HR"},
{2,"Niharika","Verma",80000,"2014-06-11 09:00:00","Admin"},
{3,"Vishal","Singhal",300000,"2014-02-20 09:00:00","HR"},
{4,"Amitabh","Singh",500000,"2014-02-20 09:00:00","Admin"},
{5,"Vivek","Bhati",500000,"2014-06-11 09:00:00","Admin"},
{6,"Vipul","Diwan",200000,"2014-06-11 09:00:00","Account"},
{7,"Satish","Kumar",75000,"2014-01-20 09:00:00","Account"},
{8,"Geetika","Chauhan",9000,"2014-04-11 09:00:00","Admin"}


 };
 
 bonus bon_arr[5]={
 	{1,"2016-02-20 00:00:00",5000},
	{2,"2016-06-11 00:00:00",3000},
	{3,"2016-02-20 00:00:00",4000},
	{1,"2016-02-20 00:00:00",4500},
	{2,"2016-06-11 00:00:00",3500}
 };
 
 title tit_arr[8]={
 	{1,"Manager","2016-02-20 00:00:00"},
	{2,"Executive","2016-06-11 00:00:00"},
	{8,"Executive","2016-02-20 00:00:00"},
	{5,"Manager","2016-06-11 00:00:00"},
	{4,"Asst Manager","2016-06-11 00:00:00"},
	{7,"Executive","2016-06-11 00:00:00"},
	{6,"Lead","2016-06-11 00:00:00"},
	{3,"Lead","2016-06-11 00:00:00"},
 };
int main()
{
	int hr_max_sal=0,hr_max_index=0,hr_salary=0,hr_total_sal=0,admin_total_salary=0,
	admin_max_index=0,admin_max_salary=0,sccount_max_index=0,account_max_salary=0,
	account_total_salary=0;
	for(int i=0;i<8;i++)
	{
	if(strcmp("HR",wor_arr[i].dep)==0)
	{
		if(hr_max_sal<wor_arr[i].salary)
		{
			hr_max_index=i;
		}
		hr_total_sal+=wor_arr[i].salary;
	}
		
	else 	if(strcmp("Admin",wor_arr[i].dep)==0)
		{
			if(admin_max_salary<wor_arr[i].salary)
			{
				admin_max_index=i;
			}
			admin_total_salary+=wor_arr[i].salary;
		}

	
	
	else 	if(strcmp("Account",wor_arr[i].dep)==0)
		{
			if(account_max_salary<wor_arr[i].salary)
			{
				sccount_max_index=i;
			}
			account_total_salary+=wor_arr[i].salary;
		}
	}
	printf("\t\tMUHAMMAD ZOHAIB RAZA \t\t\n23k-0546");
	printf("\n*************************************************************************************************\n");
	printf("00%d|\t%s\t|%s\t|%d\t|%s\t|%s",wor_arr[hr_max_index].worker_id,wor_arr[hr_max_index].f_name,wor_arr[hr_max_index].l_name,wor_arr[hr_max_index].salary,wor_arr[hr_max_index].date,wor_arr[hr_max_index].dep);
	
		printf("\n*************************************************************************************************\n");
	printf("00%d|\t%s\t|%s\t|%d\t|%s\t|%s",wor_arr[admin_max_index].worker_id,wor_arr[admin_max_index].f_name,wor_arr[admin_max_index].l_name,wor_arr[admin_max_index].salary,wor_arr[admin_max_index].date,wor_arr[admin_max_index].dep);
	
		printf("\n*************************************************************************************************\n");
	printf("00%d|\t%s\t|%s\t|%d\t|%s\t|%s",wor_arr[sccount_max_index].worker_id,wor_arr[sccount_max_index].f_name,wor_arr[sccount_max_index].l_name,wor_arr[sccount_max_index].salary,wor_arr[sccount_max_index].date,wor_arr[sccount_max_index].dep);
	
		printf("\n*************************************************************************************************\n");
		printf("HR __   %d",hr_total_sal);
		printf("\nAdmin __ %d",admin_total_salary);
		printf("\nAccount __%d",account_total_salary);
	}