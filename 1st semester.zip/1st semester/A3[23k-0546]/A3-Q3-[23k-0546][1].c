#include<stdio.h>
#include<string.h>
#include<stdlib.h>
typedef struct personal{
	int id;
	char name[20];
}personal;

typedef struct dept{
	int id;
	int salary;
}dept;

typedef struct combination{
	int id ;
	char name[100];
	int salary;
}combination;
int main()
{
	printf("\tMUHAMMAD ZOHAIB RAZA\t23k-0546\n");
	int n,id;
	char name[100];
	FILE* ptr1;
	ptr1=fopen("personal.txt","w");
	printf("enter the no of enteries\n :      ");
	scanf("%d",&n);
	personal pers[n];
	
	for(int i=0;i<n;i++)
	{
		printf("enter the ID of person %d\n",i+1);
		scanf("%d",&pers[i].id);
			printf("enter the name of person %d\n",i+1);
			scanf("%s",pers[i].name);
			
			
			fprintf(ptr1,"%d,%s",pers[i].id,pers[i].name);
			fprintf(ptr1,"\n");
	}
		FILE* ptr2;
	ptr2=fopen("department.txt","w");
	 dept dep[n];
	 	for(int i=0;i<n;i++)
	{
		printf("enter the ID of person %d\n  : " ,i+1);
		scanf("%d",&dep[i].id);
			printf("enter the salary of person  %d\n  : ",i+1);
			scanf("%d",&dep[i].salary);
			fprintf(ptr2,"%d,%d",dep[i].id,dep[i].salary);
			fprintf(ptr2,"\n");
	}
			FILE* ptr3;
	ptr3=fopen("combination.txt","w");
	combination comb[n];
	 	for(int i=0;i<n;i++)
	{
	   if(pers[i].id==dep[i].id)
	   {
	   	fprintf(ptr3,"%d,%s,%d",pers[i].id,pers[i].name,dep[i].salary );
	   	fprintf(ptr3,"\n");
	   }
	}
}