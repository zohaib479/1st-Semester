#include<stdio.h>
#include<string.h>
#include<time.h>
#include<stdlib.h>

#define MIN_VALUE 1
#define MAX_VALUE 100

int sum_max(int A,int B,int C,int D)
{
	int max=A;
	if(A<B)
	{
		max=B;
	}
	if(B<C)
	{
		max=C;
	}
	if(max<D)
	{
		max=D;
	}
	
	return max;
}
int get_random_value(int min,int max)
{
	return rand()%(max-min+1)+min;
}
int get_random_index(int min,int max)
{
	return rand()%(max-min+1)+min;
}
typedef struct HR{
	char name[5][20];
	char role[5][25];
	int commu[5];
	int Tw[5];
	int creat[5];
}HR;

typedef struct Finance{
	char name[5][20];
	char role[5][25];
	int commu[5];
	int Tw[5];
	int creat[5];
}Finance;

typedef struct Marketing{
	char name[5][20];
	char role[5][25];
	int commu[5];
	int Tw[5];
	int creat[5];
}Marketing;

typedef struct Logistics{
	char name[5][20];
	char role[5][25];
	int commu[5];
	int Tw[5];
	int creat[5];
}Logistics;

int main()
{
	printf("\t\t\tMUHAMMAD ZOHIAB RAZA \t\t23k-0546\n\n");
	int sum1=0,sum2=0,sum3=0,sum4=0,sum5=0,sum6=0,sum7=0,sum8=0,sum9=0,sum10=0,sum11=0,sum12=0,sum_marketing=0,sum_Finance=0,sum_Logistic=0,sum_HR=0;
	srand(time(NULL));
	char *dept[]={"Director","Executive","Manager","Employee","Trainee"};
	int depts=sizeof(dept)/sizeof(dept[0]);
	char *name[]={"Alice", "Bob", "Charlie", "David", "Emma", 
"Frank", "Grace", "Henry","Isabel", "Jack", "Katherine", "Liam", "Mia", "Noah", "Olivia", "Peter",
            "Quinn", "Rachel", "Samuel", "Taylor"};
	int names=sizeof(name)/sizeof(name[0]);
  HR hr;
   //assigining names to each employeee;
   for(int i=0;i<5;i++)
   {
   	int names_index=get_random_index(0,names-1);
     strcpy(hr.name[i],name[names_index]) ;
     hr.name[i][sizeof(hr.name[i])-1]='\0';
	 }
	
	 
	 for(int i=0;i<5;i++)
	 {
	 	int dept_index=get_random_index(0,depts-1);
	 	strcpy(hr.role[i],dept[dept_index]);
	 	hr.role[i][sizeof(hr.role[i])-1]='\0';
	 }
	 

	  Marketing mr;
   //assigining names to each employeee;
   for(int i=0;i<5;i++)
   {
   	int names_index=get_random_index(0,names-1);
     strcpy(mr.name[i],name[names_index]) ;
    mr.name[i][sizeof(mr.name)-1]='\0';
	 }
	 for(int i=0;i<5;i++)
	 {
	 	int dept_index=get_random_index(0,depts-1);
	 	strcpy(mr.role[i],dept[dept_index]);
    mr.role[i][sizeof(mr.role)-1]='\0';
	 }
	 
	  Finance fr;
   //assigining names to each employeee;
   for(int i=0;i<5;i++)
   {
   	int names_index=get_random_index(0,names-1);
     strcpy(fr.name[i],name[names_index]) ;
     fr.name[i][sizeof(fr.name)-1]='\0';
    
	 }
	 	 for(int i=0;i<5;i++)
	 {
	 	int dept_index=get_random_index(0,depts-1);
	 	strcpy(fr.role[i],dept[dept_index]);
	  fr.role[i][sizeof(fr.role)-1]='\0';
	 }
	 
	  Logistics lr;
   //assigining names to each employeee;
   for(int i=0;i<5;i++)
   {
   	int names_index=get_random_index(0,names-1);
     strcpy(lr.name[i],name[names_index]) ;
   lr.name[i][sizeof(lr.name)-1]='\0';
	 }
	 	 for(int i=0;i<5;i++)
	 {
	 	int dept_index=get_random_index(0,depts-1);
	 	strcpy(lr.role[i],dept[dept_index]);
	lr.role[i][sizeof(lr.role)-1]='\0';
		 }
	 
	  for(int i=0;i<5;i++)
	  {
	  	lr.commu[i]=get_random_value(MIN_VALUE,MAX_VALUE);
	  	sum1=lr.commu[i];
	  	lr.creat[i]=get_random_value(MIN_VALUE,MAX_VALUE);
	  	sum2=lr.creat[i];
	  	lr.Tw[i]=get_random_value(MIN_VALUE,MAX_VALUE);
	  	sum3=lr.Tw[i];
	  }
	  sum_Logistic=sum1+sum2+sum3;
//	  marketing departmen
	  for(int i=0;i<5;i++)
	  {
	  	
	  	mr.commu[i]=get_random_value(MIN_VALUE,MAX_VALUE);
	  	sum4=mr.commu[i];
	  	mr.creat[i]=get_random_value(MIN_VALUE,MAX_VALUE);
	  	sum5=mr.creat[i];
	  	mr.Tw[i]=get_random_value(MIN_VALUE,MAX_VALUE);
	  	sum6=mr.Tw[i];
	  }
	  sum_marketing=sum4+sum5+sum6;
	  	//hr department
	  	for(int i=0;i<5;i++)
	  	{
	  		  hr.Tw[i]=get_random_value(MIN_VALUE,MAX_VALUE);
	  		  sum7=hr.Tw[i];
	  	hr.commu[i]=get_random_value(MIN_VALUE,MAX_VALUE);
	  	sum8=hr.commu[i];
	  	hr.creat[i]=get_random_value(MIN_VALUE,MAX_VALUE);
	  	sum9=hr.creat[i];
		  }
		  sum_HR=sum7+sum8+sum9;
//		  finance department 
		  for(int i=0;i<5;i++)
		  {
		  		fr.commu[i]=get_random_value(MIN_VALUE,MAX_VALUE);
		  		sum10=fr.commu[i];
	  	fr.creat[i]=get_random_value(MIN_VALUE,MAX_VALUE);
	  	sum11=fr.creat[i];
	  	fr.Tw[i]=get_random_value(MIN_VALUE,MAX_VALUE);
	  	sum12=fr.Tw[i];
		  }
		  sum_Finance=sum10+sum11+sum12;
		  int A=sum_Logistic;
		 int  B=sum_marketing;
		 int  C=sum_HR;
		 int  D=sum_Finance;
	    int c= sum_max(A,B,C,D);
       if(c==A)
       {
       	printf("\tBEST DEPARTMENT \n\tLOGISTIC Department:\n");
       	  for (int i=0;i<5;i++)
	 {
        printf("Name: %s                Role: %s          Communication: %d         Teamwork: %d         Creativity: %d\n",
             lr.name[i], lr.role[i], lr.commu[i], lr.Tw[i], lr.creat[i]);
          }
       	
}
	   else if(c==B)
	   {
	   	     	   	       printf("\tBEST DEPARTMENT \nMARKETING Department:\n");
    for (int i=0;i<5;i++)
	 {
        printf("Name: %s                Role: %s          Communication: %d         Teamwork: %d         Creativity: %d\n",
             mr.name[i], mr.role[i], mr.commu[i], mr.Tw[i], mr.creat[i]);
         }
	   }
	   else if(c==C)
	   {
	   	    	   	       printf("\tBEST DEPARTMENT \nHR Department:\n");
    for (int i=0;i<5;i++)
	 {
        printf("Name: %s                Role: %s          Communication: %d         Teamwork: %d         Creativity: %d\n",
             hr.name[i], hr.role[i], hr.commu[i], hr.Tw[i], hr.creat[i]);
         }
         
	   }
         else if(c==D)
         {
         	        	   	       printf("\tBEST DEPARTMENT \nFINANCE Department:\n");
    for (int i=0;i<5;i++)
	 {
        printf("Name: %s                Role: %s          Communication: %d         Teamwork: %d         Creativity: %d\n",
             fr.name[i], fr.role[i], fr.commu[i], fr.Tw[i], fr.creat[i]);
	   }
		 }
	
	printf("\n\n");
	     printf("\t\t\tHR Department\n");
    for (int i=0;i<5;i++)
	 {
        printf("Name: %s                Role: %s          Communication: %d         Teamwork: %d         Creativity: %d\n",
             hr.name[i], hr.role[i], hr.commu[i], hr.Tw[i], hr.creat[i]);
         }
         printf("\n\n");
                  	   	       printf("\t\t\tFINANCE Department:\n");
    for (int i=0;i<5;i++)
	 {
        printf("Name: %s                Role: %s          Communication: %d         Teamwork: %d         Creativity: %d\n",
             fr.name[i], fr.role[i], fr.commu[i], fr.Tw[i], fr.creat[i]);
	   }
	   printf("\n\n");
	          	   	       printf("\n\t\t\tMARKETING Department:\n");
    for (int i=0;i<5;i++)
	 {
        printf("Name: %s                Role: %s          Communication: %d         Teamwork: %d         Creativity: %d\n",
             mr.name[i], mr.role[i], mr.commu[i], mr.Tw[i], mr.creat[i]);
         }
          printf("\n\n");
             	       printf("\t\t\tLOGISTIC Department:\n");
    for (int i=0;i<5;i++)
	 {
        printf("Name: %s                Role: %s          Communication: %d         Teamwork: %d         Creativity: %d\n",
             lr.name[i], lr.role[i], lr.commu[i], lr.Tw[i], lr.creat[i]);}}
