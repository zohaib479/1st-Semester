 
#include<stdio.h> 
 	void max1(int arr[2][2])  
	 	{ 
 	    	int max=arr[0][0]; 
 	    	for(int i=0;i<2;i++)  	    
			 	{ 
 	    	 	for(int j=0;j<2;j++) 
 	    	 	{ 
 	    	 	 	if(max<arr[i][j])  	    	 
					   	 	{ 
 	    	 	 	 	max=arr[i][j]; 
 	 	 	 	   } 
 	 	 	   } 
 	 	   } 
 	 	   printf("\n %d",max); 
			  	} 
 	void max2(int brr[4][4]) 
 	{ 
 	 	 
 	 	int maxi1=brr[0][0];  	 
    if (maxi1 < brr[0][1])  
 	{ 
        maxi1 = brr[0][1]; 
    } 
    if (maxi1 < brr[1][0])  
 	{ 
        maxi1 = brr[1][0]; 
    } 
    if (maxi1< brr[1][1]) 
	 	 { 
        maxi1 = brr[1][1]; 
    } 
 
 
 	 	 
int maxi2=brr[0][2];  	
if(maxi2<brr[0][3])  
	{ 
 	 	maxi2=brr[0][3];  
		  	} 
	 	if(maxi2<brr[1][2]) 
 	 	{ 
 	 	 	maxi2=brr[1][2];  
			   	 	} 
 	 	if(maxi2<brr[1][3]) 
 	 	{ 
 	 	 	maxi2=brr[1][3];  	 
			   	} 
 	  	 	 
 	 	int maxi3=brr[2][0];  
		  
		  	 	if(maxi3<brr[2][1])  
				   	 	{ 
 	 	 	maxi3=brr[2][1];  	 
			   	} 
 	 	if(maxi3<brr[3][0]) 
 	 	
 	 	{ 
 	 	 	maxi3=brr[3][0];  	 
			   	} 
 	 	if(maxi3<brr[3][1]) 
 	 	{ 
 	 	 	maxi3=brr[3][1];  	 
			   	} 
 	 	int maxi4=brr[2][2];  	 
		  	if(maxi4<brr[2][3])  	 
			  	{ 
 	 	 	maxi4=brr[2][3]; 
 	 	} 
 	if(maxi4<brr[3][2])  	{ 
	 	 	maxi4=brr[3][2]; 
	 	} 
	 	if(maxi4<brr[3][3]) 
	 	{ 
maxi4=brr[3][3];  	} 
 	int max_arr[2][2];  
	 	max_arr[0][0]=maxi1; 
		  	max_arr[0][1]=maxi2;  
			  	max_arr[1][0]=maxi3;  
				  	 	max_arr[1][1]=maxi4; 
 	 	for(int i=0;i<2;i++)  	 
		  	{ 
 	 	 	for(int j=0;j<2;j++) 
 	 	 	{ 
 	 	 	 	printf("  %d",max_arr[i][j]); 
					 	 	 	} 
 	 	 	printf("\n"); 
 	 	}  	} 
 	 	int find_max(int a,int b,int c,int d)  
		  	 	{ 
 	 	 	int max=0;  	 	 	if(max<a)  	
			    	 	{ 
 	 	 	 	max=a; 
 	 	 	} 
 	 	 	if(max<b)  	 	 
			   	{ 
 	 	 	 	max=b;  	 	
					 	} 
 	 	 	if(max<c)  	 	 
			   	{ 
 	 	 	 	max=c;  	 	
					 	} 
 	 	 	if(max<d) 
 	 	 	{ 
 	 	 	 	max=d; 
	 	 	} 
 	 	return max;  
		  	} 
 	 
 
void max3(int crr[8][8]) 
{
 int res_matrix[4][4],m=0,k=0;  for(int i=0;i<8;i=i+2) 
	 	{ 
 	 	for(int j=0;j<8;j=j+2)  	
		   	{ 
 	 	 	 	res_matrix[m][k]=find_max(crr[i][j],crr[i][j+1],crr[i+1][j],crr[i+1][j+1]); 
 	 	 	 	k++; 
 	 	 	} 
 	 	 	m++;  	 	
			   } 
 	 	 
 	 	printf("\n"); 
 	 	for(int i=0;i<4;i++) 
 	 	{ 
 	 	 	for(int j=0;j<4;j++)  	 
			   	 	{ 
 	 	 	 	printf("%d",res_matrix[i][j]); 
 	 	 	 	  	 	 
								
									} 
 	 	 	printf("\n"); 
 	 	} 
} 
int main() 
{ int n; 
   printf("enter 1 for 2 by 2 matrix \n enter 2 for 4 by 4 matrix \nenter 3 for 8 by 8 matrix : ");    scanf("%d",&n); 
 	int choice ; 
 	switch(n)  	{  	 	case 1:  
 	 	{ 
 	      int arr[2][2];       printf("\nenter the elements!: "); 
      for(int i=0;i<2;i++) 
      { 
	       	for(int j=0;j<2;j++) 
	       	{ 
       	 	printf("\nenter the elements in %d row and in %d column",i+1,j+1);        	scanf("%d",&arr[i][j]); 
       	 	  	 	  } 
 	 	  max1(arr);  	  } 
	 	 break; 
 	 	 	} 	  	      case 2:  	       	{ 
 	       int brr[4][4]; 
           printf("\nenter the elements!: ");        for(int i=0;i<4;i++) 
 	      { 
 	       	for(int j=0;j<4;j++) 
 	       	{ 
 	       	 	printf("\nenter the elements in %d row and in %d column",i+1,j+1);  	       	 	scanf("%d",&brr[i][j]);  	 	 	  } 
 	 	  } 
 	 	  max2(brr);  	 	  break; 
 	 	 	  }  	       case 3: 
 	        	{ 
 	        int crr[8][8]; 
            printf("\nenter the elements!: ");        for(int i=0;i<8;i++) 
 	      { 
 	       	for(int j=0;j<8;j++) 
 	       	{ 
 	       	 	printf("\nenter the elements in %d row and in %d column",i+1,j+1);  	       	 	scanf("%d",&crr[i][j]); 
 	 	 	  } 
 	 	  } 
 	 	  max3(crr);  	  break;  	 	   } 
	 	 	   default: 
	 	 	    	printf("incorrect input:!!!!"); 
 	 	    	 
     } 
}
