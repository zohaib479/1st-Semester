#include<stdio.h>
int main()
{
	int i,j,m,n,c,r,k,p,q;
	printf("enter no of rows in matrix 1 \n");
	scanf("%d",&r);
	printf("enter no of columns in matrix 1\n ");
	scanf("%d",&c);
	int arr[r][c];
		printf("enter no of rows in matrix 2 \n");
	scanf("%d",&p);
	printf("enter no of columns in matrix 2\n ");
	scanf("%d",&q);
	int brr[p][q];
	if(c==p)
	{
		printf("multiplication is possible :");
	}
	else
	{
		printf("multiplication is not possible :");
		return 0;
	}
	printf("enter the elements of matrix 1 : ");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			scanf("%d",&arr[i][j]);
		}
	}
	printf("\n");
		printf("enter the elements of matrix 2 : ");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			scanf("%d",&brr[i][j]);
		}
	}
	printf("\n");
	int res[r][q];
	for(i=0;i<r;i++)
	{
		for(j=0;j<q;j++)
		{
			res[i][j]=0;
	
		  for(int k=0;k<c;k++)
		  {
		  	res[i][j]+=arr[i][k]*brr[k][j];
		  }
		}
	}
	printf("\n");
		for(i=0;i<r;i++)
	{
		for(j=0;j<q;j++)
		{
		 printf("%d ",res[i][j]);

		}printf("\n");
	}

}