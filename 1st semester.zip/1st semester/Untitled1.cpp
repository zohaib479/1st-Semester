#include<stdio.h>
int main ()
{
	int arr[2][3]={
	{8,9,3},
	{6,3,0}};
	for (int i=0;i<2;i++)
	{
		for(int j=0;j<3-1;j++)
		{
			for(int k=0;k<3-1;k++)
			{
				if(arr[i][k]>arr[i][k+1])
				{
					int temp;
					temp=arr[i][k];
					arr[i][k]=arr[i][k+1];
					arr[i][k+1]=temp;
				}
			}
		}
	}
	
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<3;j++)
		{
			printf("%d ",arr[i][j]);
		}
		printf("\n");
	}
}
