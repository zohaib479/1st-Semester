#include<stdio.h>
int main()
{
	int i,freq,N,key;
	printf("enter the size of array : ");
	scanf("%d",&N);
	int arr[N];
	for(i=0;i<N;i++)
	{
		printf("enter the number: ");
		scanf("%d",&arr[i]);
	}
	printf("enter the number you want to know frequency: ");
	scanf("%d",&key);
	for(i=0;i<N;i++)
	{
		if(arr[i]==key)
		{
			freq++;
		}
	}
	printf("\n");
	printf("the frequency of %d is % d : ",key,freq);
}