#include<stdio.h>
#include<ctype.h>
#include<stdlib.h>
int main()
{
   FILE *ptr1=fopen("zohaib.txt","r");
   FILE *ptr2=fopen("NEW.txt","w");
   
   
   
   char ch = fgetc(ptr1);
   while (ch!=EOF)
   {
   	printf("\nnormal read: %c", ch);
   	if(islower(ch))
   	{
   		ch=toupper(ch);
   		printf("\ncapitalize: %c", ch);	
	}
	fputc(ch,ptr2);
   	ch = fgetc(ptr1);
   }
}