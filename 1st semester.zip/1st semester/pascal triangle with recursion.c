#include<stdio.h>
int fact(int x)
{
	int factorial=1;
//	int m=1;
    for(int i=x;i>=1;i--)
    {
    	factorial*=i;
	}
	return factorial;
	
}
int comb(int n,int r)
{
	int numerator=fact(n);
	int denominator=fact(r)*fact(n-r);
	return  numerator/(denominator);
}
int main()
{
	int r,n;
	printf("enter total no lines: \n");
	scanf("%d",&n);

	for(int i=0;i<n;i++)
	{
		for(int j=0;j<=i;j++)
		{
			int icj=comb(i,j);
			printf(" %d",icj);
		}
		printf("\n");
	}

}