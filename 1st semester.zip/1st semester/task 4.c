#include<stdio.h>
int main(){
	int i,n,j,d;
	printf("enter the quantity of numbers: ");
	scanf("%d",&n);
	printf("enter the rotaion: ");
	scanf("%d",&d);
	int b=n-d;
	int arr[n];
	for(i=b;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	for(i=0;i<b;i++)
	{
		scanf("%d",&arr[i]);
	}
	printf("\n");
	for(i=0;i<n;i++)
	{
		printf("% d",arr[i]);
	}
}