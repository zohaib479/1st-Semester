var a:number;
// a="code with zohaib";
console.log(a);