#include<stdio.h>
int main(){
int  N,month,sum=0,avg=0;
int salary[N];
printf("enter how many months:");
   scanf("%d",&N);
    for(int i=0;i<N;i++){
printf("enter the salary");
scanf("%d",&salary[i]);
sum+=salary[i];
}
  for(int i=0;i<N;i++)
  {
  	for(int j=i+1;j<N;j++)
  	{
  		if(salary[i]>salary[j])
  		{
  			int temp;
  			temp=salary[i];
  			salary[i]=salary[j];
  			salary[j]=temp;
		}
    }
  }
   printf("the salary in ascending order:");
   for(int i=0;i<N;i++)
   {
   	printf("% d\n",salary[i]);
   }
printf("the sum is %d",sum);
avg=sum/N;
printf("\nthe average is %d",avg);
}