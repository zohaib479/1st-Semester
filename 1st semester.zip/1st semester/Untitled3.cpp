#include<stdio.h>
int main ()
{
	int n,m;
	printf("enter the size of rows  : \n");
	scanf("%d",&n);
	printf("enter the no of columns  : \n");
	scanf("%d",&m);
	int arr[n][m];
	for(int i=0;i<n;i++)
	{
		printf("enter the element in %d rows \n",i+1);
		for(int j=0;j<m;j++)
		{
			printf("enter the element in %d colomn: ",j+1);
			scanf("%d",&arr[i][j]);
		}
	}
	
	
	
	printf("\nprinting the arrray:\n ");
	printf("\n");
		for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
		
		printf("%d  ",arr[i][j]);
		}
		printf("\n");
	}
	

	  int  max=arr[0][0];
	  for (int i=0;i<n;i++)
	  {
	  	for(int j=0;j<m;j++)
	  	{
	  		
	  		if(max<arr[i][j])
	  		{
	  			max=arr[i][j];
			}
		  }
		}
	  
	  printf("\n\n the maximum number \n");
	  printf("maximum is %d ",max);
	  
	  printf("\n");
	  for(int i=0;i<n;i++)//row badalny k lyai 
	  {
	  	for(int j=0;j<m-1;j++)//column badalny k lyai 
	  	{
	  		for(int k=0;k<m-1-j;k++)//baar baar peeechy aakr deikhy ny k lyai 
	  		{
	  			if(arr[i][k]>arr[i][k+1])
	  			{
	  				int temp;
	  				temp=arr[i][k+1];
	  				arr[i][k+1]=arr[i][k];
	  				arr[i][k]=temp;
				  }
	        }
		  }
	  }
	  
	  
	  		for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
	printf("%d  ",arr[i][j]);
		}
		printf("\n");
	}
	
	
	printf("\n");
	//column sorting 
	
	for (int i=0;i<m-1;i++)
	{
		for (int j=0;j<n-1;j++)
		{
			for (int k=0;k<n-1-j;k++)
			{
				if(arr[k][i]>arr[k+1][i])
				{
				int temp;
				temp=arr[k+1][i];
				arr[k+1][i]=arr[k][i];
				arr[k][i]=temp;
				}
			}
		}
	}
		  		for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
	printf("%d  ",arr[i][j]);
		}
		printf("\n");
	}
	
	
	
	
}