#include<stdio.h>
int main ()
{
	int GCD;
	int n,k;
	printf("enter the 1st number : \n");
	scanf("%d",&n);
	printf("enter the 2nd number : \n");
	scanf("%d",&k);
	int min=0;
	if(n<k)
	{
		min=n;
	}
	else 
	min=k;
	for(int i=1;i<=min;i++)
	{
      if (k%i==0&&n%i==0)
      {
      	GCD=i;
	  }
	}
	printf("%d  ",GCD);
}