#include <stdio.h>
#include <string.h>

int main() {
    char seq[10];
    char nucleotide[] = { 'A', 'G', 'C', 'T' };
    int freq[4] = { 0 }; // Initialize the frequency array to zeros
    int i = 0;

    printf("Enter the input sequence (up to 10 characters): ");
    scanf("%s", seq);

    while (seq[i] != '\0') {
        switch (seq[i]) {
        case 'A':
            freq[0]++;
            break;
        case 'G':
            freq[1]++;
            break;
        case 'C':
            freq[2]++;
            break;
        case 'T':
            freq[3]++;
            break;
        default:
        	printf("no match found  !");
        }
        i++;
    }

    for (i = 0; i < 4; i++) {
        printf("%c: ", nucleotide[i]);
        for (int j = 0; j < freq[i]; j++) {
            printf("*");
        }
        printf("\n");
    }

    return 0;
}
