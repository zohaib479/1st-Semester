#include<stdio.h>
void shift_left(int p[],int  n,int d)
{
	
	printf("enter an array of length: 5\n");
     for(int i=d+1;i<5;i++)
     {
     	scanf("%d",&p[i]);
	 }
	 for(int i=0;i<=d;i++)
	 {
	 	scanf("%d",&p[i]);
	 }
	 for(int i=0;i<5;i++)
	 {
	 	printf("%d  ",p[i]);
	 	
	 }
}
int main()
{
	int p[5];
	int d;
	//d=rotaion no ????
	printf("enter the rotation: ");
	scanf("%d",&d);
//	for(int i=0;i<5;i++)
//	{
//		scanf("%d",&p[i]);
//	}
	shift_left(p,5,d);
}
